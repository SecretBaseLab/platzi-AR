﻿using UnityEngine;
using System.Collections;

public class URL : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
      
    }

    public void link ()
    {
        Application.OpenURL("http://www.idrd.gov.co/sitio/idrd/content/estadio-nemesio-camacho-el-campin");
    }
   
}
